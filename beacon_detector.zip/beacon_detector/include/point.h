#pragma once

#include "pose.h"

#include <vector>

class Point{

    public:
        Pose pose;
        
        bool visited;
        int class_; // Noise, Unassigned, Core, Border
        std::vector<Point*> neighbours;

        Point(double x, double y);

};