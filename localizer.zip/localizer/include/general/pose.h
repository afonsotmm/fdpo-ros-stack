#pragma once

struct Pose {

    double x, y;

};